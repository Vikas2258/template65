import React from 'react'
import '../Css/Div3.css'

function Div3() {
  return (
    <div>
        <div className="l-unconstrained-2">
  <div className="l-constrained-2">
    <div className="row-17 group">
      <div className="rectangle-8-copy-5" />
      <p className="text-51">What is Says Our Customer</p>
    </div>
    <div className="wrapper-19">
      <div className="ellipse-2-holder">
        <img
          className="arrow-point-to-right"
          src="images/arrow-point-to-right.png"
          alt=""
          width={8}
          height={14}
        />
      </div>
      <div className="ellipse-2-copy-holder">
        <img
          className="arrow-point-to-right-copy"
          src="images/arrow-point-to-right_copy.png"
          alt=""
          width={8}
          height={14}
        />
      </div>
      <div className="row-8 group">
        <div className="wrapper-10">
          <div className="rectangle-32" />
          <img className="rectangle-33" src="images/rectangle_33.jpg" alt="" />
        </div>
        <div className="wrapper-11 group">
          <div className="rectangle-34" />
          <p className="majority">Majority</p>
          <p className="text-52">
            There are many variations of passages of Lorem Ipsum available, but
            the majority have suffered alteration in some form, by injected
            humour, or randomised words which don't look even slightly
            believable.
          </p>
        </div>
      </div>
    </div>
    <div id='login-section' className="row-9 group">
      <div className="rectangle-8-copy-6" />
      <p className="text-53">Get In Touch</p>
    </div>
    <div className="row-6 match-height group">
      <img
        className="london-google-maps"
        src="images/london_-_google_maps.png"
        alt=""
        width={794}
        height={634}
      />
      <div className="col-7">
        <div className="rectangle-24-holder">Name</div>
        <div className="rectangle-24-copy-holder">Email</div>
        <div className="rectangle-24-copy-2-holder">Phone Number</div>
        <div className="rectangle-24-copy-3-holder">Message</div>
        <div className="rectangle-25-holder">Send</div>
      </div>
    </div>
  </div>
</div>

      
    </div>
  )
}

export default Div3
